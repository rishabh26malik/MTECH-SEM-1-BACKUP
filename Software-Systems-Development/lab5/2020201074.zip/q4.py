sent=input()
output="".join(reversed(sent))
print(output)