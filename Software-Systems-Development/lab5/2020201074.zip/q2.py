ch=input()
ch=ch.lower()
if(ch=='a' or ch=='e' or ch=='i' or ch=='o' or ch=='u'):
	print("True")
else:
	print("False")