### SSD Lab-5 Activity

**1.)** Took both input integers in same line, typecasted them to integers as it is of string type by default and splitted them by using blank space(" ") as delimiter using `split()` function
**2.)** Converted character to lower case before checking
**3.)** Took input as comma separated words. Converted it into list by splitting using comma as delimiter.  Used `map()` function to map word with its length and stored it in a list.
**Output** is list of length of each word.
**4.)** used `reversed()` function to reverse the input string.