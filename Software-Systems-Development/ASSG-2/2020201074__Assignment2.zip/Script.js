$(document).ready(function(){
  $("#flipSkill").click(function(){
    $("#panelSkill").slideToggle("slow");
  });

  $("#flipProj").click(function(){
    $("#panelProj").slideToggle("slow");
  });

  $("#flipPub").click(function(){
    $("#panelPub").slideToggle("slow");
  });

  $("#flipIntern").click(function(){
    $("#panelIntern").slideToggle("slow");
  });

  $("#flipAchv").click(function(){
    $("#panelAchv").slideToggle("slow");
  });

  $("#flipEdu").click(function(){
    $("#panelEdu").slideToggle("slow");
  });
      
  $("#flipContent").click(function(){
    $("#panelContent").slideToggle("slow");
  });

  $("#flipGoal").click(function(){
    $("#panelGoal").slideToggle("slow");
  });

  $("#flipEval").click(function(){
    $("#panelEval").slideToggle("slow");
  });

  $("#flipSub").click(function(){
    $("#panelSub").slideToggle("slow");
  });
  $("#flipExp").click(function(){
    $("#panelExp").slideToggle("slow");
  });
});