### SSD Assignment-2
- Bootstrap and Jquery are the frameworks that have been used. Bootstrap is used to create  a nav bar on top of each page. Jquery is used to produce some better user experience effects like hiding and showing particular information by clicking on it.   
