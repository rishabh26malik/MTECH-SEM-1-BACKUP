### SSD Lab-4 Activity

**a.)** For `Drop Down`
- I have stored data values in an array
- Then, I have appended all array values enclosed in `<option>` tag to the string
- The string contains the entire html text which comprises of tags like `select`, `option`, which would otherwise if written as html text would create a drop down.
- Now this string is added to the web page using jquery.

**b.)** For `Background`
- Whenever `button` is clicked, event is called using jquery, which updates the css by adding a background image.
- local image is used

**c.)** For `keystroke` detection
- `input` tag is used to read input from user
- Event `keypress` is called whenever any data in entered inside the input field
- `51` is the ASCII value of 3

**d.)** For `Blinking`
- `fadeIn` and `fadeOut` are used to generate a blinking effect.
- Each occur for 500ms and this continues.

 