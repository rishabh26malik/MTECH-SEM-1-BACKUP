#!/bin/bash
cd /usr/local/lib
d /home/rishabh/lab1
cd /usr/local/lib
cd
mkdir /home/rishabh/Documents/LabActivity1
cd /home/rishabh/Documents/LabActivity1

